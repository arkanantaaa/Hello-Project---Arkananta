#ifndef MULTILINKED_H_INCLUDED
#define MULTILINKED_H_INCLUDED
#include <iostream>
///Hilal Gibran
//1301204095
///Muhammad Hafizh Arkananta
//1301202155

/*  - User dapat Input MK tambahan
    dan user dapat input mahasiswa
    - Jenis mahasiswa di bedakan dua
    jenis
    - User dapat Menghapus dan Mencari
    Mahasiswa di MK tertentu
    - Setiap MK memiliki Jumlah Maksimal
*/
using namespace std;

// ADT Mahasiswa
struct infotype_Mhs {
    string nama_mhs;
    string nim_mhs;
    string asal_kelas;
    string jenis_mhs;
};
typedef struct elm_Mhs *adr_Mhs;
struct elm_Mhs {
    infotype_Mhs info;
    adr_Mhs next;
    adr_Mhs prev;
};
struct List_Mhs {
    adr_Mhs first;
    adr_Mhs last;
};


// ADT Relasi
typedef struct elm_Relation *adr_Relation;
struct elm_Relation {
    adr_Mhs next_mhs;
    adr_Relation next;
	adr_Relation prev;
};


// ADT Mata Kuliah
struct infotype_MK {
    string nama_mk;
    string nama_kelas;
    int kuota_maks;
    int jumlah;
    string jenis_mk;
};
typedef struct elm_MK *adr_MK;
struct elm_MK {
    infotype_MK info;
    adr_Relation firstrel;
    adr_MK next;

};
struct List_MK {
    adr_MK first;
    adr_MK last;
};


// Fungsi Mata Kuliah
void create_List_MK(List_MK &listmk);
adr_MK create_Element_MK(infotype_MK data_baru);
void insert_MK(List_MK &listmk, adr_MK P);
void delete_First(List_MK &listmk, adr_MK &P);
void delete_Last(List_MK &listmk, adr_MK &P);
void delete_After(adr_MK prec, adr_MK &P);
void delete_MK(List_MK &listmk, adr_MK &P);
adr_MK search_MK(List_MK listmk, string nama_mk, string nama_kelas);
void print_Matkul_Ditawarkan(List_MK listmk);

// Fungsi Mahasiswa
void create_List_Mhs(List_Mhs &listmhs);
adr_Mhs create_Element_Mhs(infotype_Mhs data_baru);
void insert_Mhs(List_Mhs &listmhs, adr_Mhs P);
void delete_First_mhs(List_Mhs &listmhs, adr_Mhs P);
void detele_After_mhs(adr_Mhs prec, adr_Mhs &P);
void delete_Last_mhs(List_Mhs &listmhs, adr_Mhs P);
void delete_Mhs(List_Mhs &listmhs, List_MK &listmk, adr_Mhs P);
adr_Mhs search_mhs(List_Mhs listmhs, string nim_mhs);
void print_mahasiswa(List_Mhs listmhs);

// Primitif Fungsi Relasi
void create_Relasi(List_MK listmk, adr_MK mk, adr_Mhs mhs);
void delete_Relasi(adr_MK mk, adr_Mhs mhs);
void print_Full(List_MK mk);
void print_Half_Full(List_MK mk, string nama_mk, string nama_kelas);
void print_MK_Kuota(List_MK mk, string nama_mk);
bool cari_Mahasiswa_di_MK(adr_MK mk, string nama_mhs);

#endif // MULTILINKED_H_INCLUDED
