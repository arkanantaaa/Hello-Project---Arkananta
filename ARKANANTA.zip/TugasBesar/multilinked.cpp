#include "multilinked.h"

void create_List_MK(List_MK &listmk) {
    //Membuat List mata kuliah baru
    listmk.first = NULL;
    listmk.last = NULL;
}

adr_MK create_Element_MK(infotype_MK data_baru) {
    //Membuat Element mata kuliah baru
    adr_MK P;
    P = new elm_MK;
    P->info = data_baru;
    P->firstrel = NULL;
    P->next = NULL;
    return P;
}

void insert_MK(List_MK &listmk, adr_MK P){
    //Menambahkan mata kuliah ke dalam list
    if (listmk.first == NULL) {
        listmk.first = P;
        listmk.last = P;
    } else {
		adr_MK Q = listmk.first;
        while (Q->next != NULL) {
            Q = Q->next;
        }
		Q->next = P;
    }
}

void delete_First(List_MK &listmk, adr_MK &P) {
    //Menghapus mata kuliah pada posisi pertama list
	listmk.first = P->next;
	P->next = NULL;
}

void delete_Last(List_MK &listmk, adr_MK &P) {
    //Menghapus mata kuliah pada posisi terakhir list
    adr_MK Q = listmk.first;
	P = listmk.last;
    Q->next = P;
    Q = listmk.last;
    P = NULL;
}

void delete_After(adr_MK prec, adr_MK &P){
    //Menghapus mata kuliah pada posisi setelah mata kuliah yang ditunjuk
    P = prec->next;
    prec->next = P->next;
    P->next = NULL;
}

void delete_MK(List_MK &listmk, adr_MK &P){
    //Menghapus mata kuliah dari list menggunakan fungsi hapus lain yang sudah dibuat
    if (P == listmk.first) {
        delete_First(listmk, P);
    } else if (P->next == NULL) {
        delete_Last(listmk, P);
    } else {
		adr_MK Q = listmk.first;
        while (P != Q->next) {
            Q = Q->next;
        }
        delete_After(Q, P);
    }
}

adr_MK search_MK(List_MK listmk, string nama_mk, string nama_kelas) {
    //Mengembalikan mata kuliah yang dicari
    adr_MK P = listmk.first;
    while (P != NULL) {
        if (P->info.nama_mk == nama_mk && P->info.nama_kelas == nama_kelas) {
            return P;
        }
        P = P->next;
    }
    return NULL;
}

void print_Matkul_Ditawarkan(List_MK listmk){
    //Menampilkan daftar matkul yang ditawarkan
    adr_MK P;
    P = listmk.first;
    cout<<"Daftar Mata Kuliah:"<<endl;
    while (P != NULL){
        cout<<"Nama Mata Kuliah : "<<P->info.nama_mk<<endl;
        cout<<"Nama Kelas : "<<P->info.nama_kelas<<endl;
        cout<<"Jumlah Mahasiswa : "<<P->info.jumlah<<"/"<<P->info.kuota_maks<<endl;
        cout << endl;
        P = P->next;
    }
}

void create_List_Mhs(List_Mhs &listmhs) {
    //Membuat list mahasiswa baru
    listmhs.first = NULL;
    listmhs.last = NULL;
}

adr_Mhs create_Element_Mhs(infotype_Mhs data_baru) {
    //Membuat element mahasiswa baru
    adr_Mhs Q;
    Q = new elm_Mhs;
    Q->info = data_baru;
    Q->next = NULL;
    Q->prev = NULL;
    return Q;
}

void insert_Mhs(List_Mhs &listmhs, adr_Mhs P) {
    //Menambahkan mahasiswa ke dalam list
    if (listmhs.first == NULL) {
        listmhs.first = P;
        listmhs.last = P;
    } else {
        listmhs.last = listmhs.first;
        while (listmhs.last->next != NULL) {
            listmhs.last = listmhs.last->next;
        }
        listmhs.last->next = P;
        P->prev = listmhs.last;
    }
}

void delete_First_Mhs(List_Mhs &listmhs, adr_Mhs P) {
    //Menghapus mahasiswa pada posisi pertama list
    if (listmhs.first != NULL) {
        listmhs.first = listmhs.first->next;
    }
    P->next = NULL;
    P->prev = NULL;
}

void delete_Last_Mhs(List_Mhs &listmhs, adr_Mhs P) {
    //Menghapus mahasiswa pada posisi terakhir list
     P = listmhs.last;
     listmhs.last = listmhs.last->prev;
     P->prev = NULL;
     listmhs.last->next = NULL;
}

void delete_After_Mhs(adr_Mhs prec, adr_Mhs &P) {
    //Menghapus mahasiswa pada posisi setelah mahasiswa yang ditunjuk
    prec->next = P->next;
    P->next->prev = prec;
    P->next = NULL;
}

void delete_Mhs(List_Mhs &listmhs, List_MK &listmk, adr_Mhs P) {
    //Menghapus mahasiswa dari list menggunakan fungsi hapus lain yang sudah dibuat
    //Selain itu juga menghapus semua relasi yang dimiliki oleh mahasiswa
    adr_MK adrMK = listmk.first;
    while (adrMK != NULL) {
        delete_Relasi(adrMK, P);
        adrMK = adrMK->next;
    }
    if (P == listmhs.first) {
        delete_First_Mhs(listmhs, P);
    } else if (P->next == NULL) {
        delete_Last_Mhs(listmhs, P);
    } else {
        adr_Mhs Q = listmhs.first;
        while (P != Q->next) {
            Q = Q->next;
        }
        delete_After_Mhs(Q, P);
    }

}

adr_Mhs search_mhs(List_Mhs listmhs, string nim_mhs){
    //Mengembalikan mahasiswa yang dicari
    adr_Mhs P = listmhs.first;
    while (P != NULL) {
        if (P->info.nim_mhs == nim_mhs) {
            return P;
        }
        P = P->next;
    }
    return NULL;
}

void print_mahasiswa(List_Mhs listmhs){
    //Menampilkan daftar mahasiswa
    adr_Mhs Q;
    if (listmhs.first == NULL) {
        cout<<"List Kosong!"<<endl;
        cout<<endl;
    } else {
        Q = listmhs.first;
        cout<<"Daftar Mahasiswa:"<<endl;
        while (Q != NULL) {
            cout<<Q->info.nama_mhs<<" - "<<Q->info.nim_mhs<<" ("<<Q->info.jenis_mhs<<")"<<endl;
            Q = Q->next;
        }
    }
}

void create_Relasi(List_MK listmk, adr_MK mk, adr_Mhs mhs) {
    //Membuat relasi baru yang menghubungkan mata kuliah dengan mahasiswa
    adr_Relation Rel = new elm_Relation;
    Rel->next_mhs =  mhs;
    Rel->prev = NULL;
    Rel->next = NULL;
    int terdaftar = 0;
    adr_MK mktemp = listmk.first;
    while(mktemp != NULL) {
        adr_Relation reltemp = mktemp->firstrel;
        while(reltemp != NULL) {
            if(reltemp->next_mhs == mhs) {
                terdaftar++;
            }
            reltemp = reltemp->next;
        }
        mktemp = mktemp->next;
    }

    //Terdapat beberapa kondisi, yaitu:
    //Mahasiswa maksimal hanya mendaftar 3 mata kuliah;
    //Mahasiswa hanya boleh mendaftar pada kelas yang jenisnya sama;
    //Mahasiswa hanya bisa mendaftar pada kelas yang kuotanya belum penuh
    if(terdaftar >= 3) {
        cout<<"Mahasiswa sudah melewati limit pendaftaran"<<endl;
    }
    else if(cari_Mahasiswa_di_MK(mk, mhs->info.nim_mhs) == true) {
        cout<<"Mahasiswa sudah terdaftar"<<endl;
    }
    else if(mhs->info.jenis_mhs == mk->info.jenis_mk) {
        if (mk->firstrel == NULL) {
            mk->firstrel = Rel;
            mk->info.jumlah++;
        } else {
            if (mk->info.jumlah == mk->info.kuota_maks) {
                cout<<"Mata kuliah Penuh"<<endl;
            } else {
                adr_Relation temp;
                temp = mk->firstrel;
                while (temp->next != NULL) {
                    temp = temp->next;
                }
                temp->next = Rel;
                mk->info.jumlah++;
            }
        }
    } else {
        cout<<"Mahasiswa tidak valid"<<endl;
    }
}

void delete_Relasi(adr_MK mk, adr_Mhs mhs) {
    //Menghapus relasi antara mata kuliah dan mahasiswa jika ditemukan
    adr_Relation P = mk->firstrel;
    while (P != NULL) {
        if (P->next_mhs == mhs) {
            mk->info.jumlah--;
            if (P == mk->firstrel) {
                mk->firstrel = P->next;
            } else {
                adr_Relation prec;
                prec = mk->firstrel;
                while (prec->next != P) {
                    prec = prec->next;
                }
                prec->next = P->next;
            }
        }
        P = P->next;
    }
}

void print_Full(List_MK mk) {
    //Menampilkan seluruh mk beserta data mahasiswanya
    adr_MK P = mk.first;
    cout<<"Daftar Seluruh MK Beserta Mahasiswanya"<<endl;
    while (P != NULL) {
        adr_Relation Q = P->firstrel;
        cout<<"Mata Kuliah : "<<P->info.nama_mk<<endl;
        cout<<"Nama Kelas  : "<<P->info.nama_kelas<<endl;
        cout<<"Mahasiswa   : "<<P->info.jumlah<<"/"<<P->info.kuota_maks<<endl;
        while (Q != NULL) {
            cout<<" -> "<<Q->next_mhs->info.nama_mhs<<endl;
            Q = Q->next;
        }
        cout << endl;
        P = P->next;
    }
}

void print_Half_Full(List_MK mk, string nama_mk, string nama_kelas) {
    //Menampilkan data mahasiswa di MK dan kelas tertentu
    adr_MK P = mk.first;
    while (P != NULL) {
        if(P->info.nama_mk == nama_mk && P->info.nama_kelas == nama_kelas) {
            cout<<"Daftar Mahasiswa Pendaftar"<<endl;
            adr_Relation Q = P->firstrel;
            cout<<"Mata Kuliah : "<<P->info.nama_mk<<endl;
            cout<<"Nama Kelas  : "<<P->info.nama_kelas<<endl;
            cout<<"Mahasiswa   : "<<P->info.jumlah<<"/"<<P->info.kuota_maks<<endl;
            while (Q != NULL) {
                cout<<" -> "<<Q->next_mhs->info.nama_mhs<<endl;
                Q = Q->next;
            }
            cout << endl;
            return;
        }
        P = P->next;
    }

    cout<<"Mata kuliah tidak ditemukan"<<endl;
}

void print_MK_Kuota(List_MK mk, string nama_mk) {
    //Menampilkan nama mk tertentu dengan kuota masih tersedia
    adr_MK P = mk.first;
    bool ada = false;
    cout<<"Daftar Mata Kuliah Dengan Kuota Tersedia:"<<endl;
    while(P != NULL) {
        if(P->info.nama_mk == nama_mk && P->info.jumlah < P->info.kuota_maks) {
            cout<<P->info.nama_kelas<<endl;
            ada = true;
        }
        P = P->next;
    }
    if(!ada) {
        cout << "Mata kuliah tidak ditemukan" << endl;
    }
}

bool cari_Mahasiswa_di_MK(adr_MK mk, string nim_mhs) {
    //Mencari nama mahasiswa tertentu pada sebuah mk
    bool ada = false;
    adr_Relation P= mk ->firstrel;
    while (P != NULL) {
        if(P->next_mhs->info.nim_mhs == nim_mhs) {
            ada = true;
            break;
        }
        P = P->next;
    }

    if(ada) {
        return true;
    } else {
        return false;
    }
}
