#include <iostream>
#include "multilinked.h"
using namespace std;

int main()
{
    system("color a4");
    cout << "Hello world!" << endl;
    // Deklarasi list dan variabel
    List_MK Matakuliah;
    create_List_MK(Matakuliah);
    adr_MK P;
    List_Mhs mahasiswa;
    create_List_Mhs(mahasiswa);
    adr_Mhs Q;

    // Template Mata Kuliah
    P = create_Element_MK({.nama_mk = "Struktur Data", .nama_kelas = "IF-44-Gab1", .kuota_maks = 3, .jumlah = 0, .jenis_mk = "Reguler"});
    insert_MK(Matakuliah,P);
    P = create_Element_MK({.nama_mk = "Struktur Data", .nama_kelas = "IF-44-Gab2", .kuota_maks = 3, .jumlah = 0, .jenis_mk = "Reguler"});
    insert_MK(Matakuliah,P);
    P = create_Element_MK({.nama_mk = "Struktur Data", .nama_kelas = "IF-44-INT", .kuota_maks = 2, .jumlah = 0, .jenis_mk = "Internasional"});
    insert_MK(Matakuliah,P);

    // Template Mahasiswa
    Q = create_Element_Mhs({.nama_mhs = "Yusuf", .nim_mhs = "103101", .asal_kelas = "IF-44-01", .jenis_mhs= "Reguler"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Silvi", .nim_mhs = "103102", .asal_kelas = "IF-44-02", .jenis_mhs= "Reguler"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Siska", .nim_mhs = "103103", .asal_kelas = "IF-44-05", .jenis_mhs= "Reguler"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Agus", .nim_mhs = "103104", .asal_kelas = "IF-44-04", .jenis_mhs= "Reguler"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Anwar", .nim_mhs = "113101", .asal_kelas = "IF-44-INT", .jenis_mhs= "Internasional"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Tony Stark", .nim_mhs = "113102", .asal_kelas = "IF-44-INT", .jenis_mhs= "Internasional"});
    insert_Mhs(mahasiswa,Q);
    Q = create_Element_Mhs({.nama_mhs = "Elsa", .nim_mhs = "113103", .asal_kelas = "IF-44-INT", .jenis_mhs= "Internasional"});
    insert_Mhs(mahasiswa,Q);\

    // Template Relasi
    P = search_MK(Matakuliah,"Struktur Data", "IF-44-Gab1");
    Q = search_mhs(mahasiswa,"103101");
    create_Relasi(Matakuliah, P,Q);
    P = search_MK(Matakuliah,"Struktur Data", "IF-44-Gab1");
    Q = search_mhs(mahasiswa,"103102");
    create_Relasi(Matakuliah, P,Q);
    P = search_MK(Matakuliah,"Struktur Data", "IF-44-Gab1");
    Q = search_mhs(mahasiswa,"103103");
    create_Relasi(Matakuliah, P,Q);
    P = search_MK(Matakuliah,"Struktur Data", "IF-44-INT");
    Q = search_mhs(mahasiswa,"113101");
    create_Relasi(Matakuliah, P,Q);

    // Fungsi Menu
    int fase = 0;
    while(fase != -1) {
        if(fase == 0) {
            int opsi;
            cout<<"Tahap Pemasukan Mata Kuliah"<<endl;
            cout<<"(1) Tambah mata kuliah"<<endl;
            cout<<"(2) Hapus mata kuliah"<<endl;
            cout<<"(3) Tampilkan mata kuliah"<<endl;
            cout<<"(0) Lanjut tahap berikutnya"<< endl;
            cout<<"Pilih : ";
            cin >> opsi;

            if (opsi == 1) {
                infotype_MK temp;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp.nama_mk);
                cout<<"Nama Kelas : ";
                cin>>temp.nama_kelas;
                temp.jumlah = 0;
                cout<<"Kuota Maksimal : ";
                cin>>temp.kuota_maks;
                cout<<"Jenis Mata Kuliah : ";
                cin>>temp.jenis_mk;
                insert_MK(Matakuliah, create_Element_MK(temp));
            } else if (opsi == 2) {
                string temp1, temp2;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp1);
                cout<<"Nama Kelas : ";
                cin>>temp2;
                P = search_MK(Matakuliah, temp1, temp2);
                delete_MK(Matakuliah, P);
            } else if (opsi == 3) {
                print_Matkul_Ditawarkan(Matakuliah);
            } else if (opsi == 0) {
                fase++;
            } else {
                cout << "Salah memasukkan pilihan" << endl;
            }
            cout << endl;
        } else if(fase == 1) {
            int opsi;
            cout<<"Tahap Pemasukan Mahasiswa"<<endl;
            cout<<"(1) Tambah mahasiswa"<<endl;
            cout<<"(2) Hapus mahasiswa"<<endl;
            cout<<"(3) Tampilkan mahasiswa"<<endl;
            cout<<"(0) Lanjut tahap berikutnya"<< endl;
            cout<<"Pilih : ";
            cin >> opsi;

            if (opsi == 1) {
                infotype_Mhs temp;
                cout<<"Nama Mahasiswa : ";
                cin.ignore();
                getline(cin, temp.nama_mhs);
                cout<<"NIM Mahasiswa : ";
                cin>>temp.nim_mhs;
                cout<<"Asal Kelas : ";
                cin>>temp.asal_kelas;
                cout<<"Jenis Mahasiswa : ";
                cin>>temp.jenis_mhs;
                insert_Mhs(mahasiswa, create_Element_Mhs(temp));
            } else if (opsi == 2) {
                string temp;
                cout<<"NIM Mahasiswa : ";
                cin>>temp;
                delete_Mhs(mahasiswa, Matakuliah, search_mhs(mahasiswa, temp));
            } else if (opsi == 3) {
                print_mahasiswa(mahasiswa);
            } else if (opsi == 0) {
                fase++;
            } else {
                cout << "Salah memasukkan pilihan" << endl;
            }
            cout << endl;
        } else if(fase == 2) {
            int opsi;
            cout<<"Tahap Registrasi"<<endl;
            cout<<"(1) Daftarkan mahasiswa ke mata kuliah"<<endl;
            cout<<"(2) Batalkan pendaftaran mahasiswa"<<endl;
            cout<<"(3) Tampilkan mata kuliah beserta pendaftar"<<endl;
            cout<<"(4) Cari kelas mata kuliah dengan kuota masih tersedia"<<endl;
            cout<<"(0) Lanjut tahap berikutnya"<< endl;
            cout<<"Pilih : ";
            cin >> opsi;

            if (opsi == 1) {
                string temp1, temp2, temp3;
                cout<<"NIM Mahasiswa : ";
                cin>>temp3;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp1);
                cout<<"Nama Kelas : ";
                cin>>temp2;
                create_Relasi(Matakuliah, search_MK(Matakuliah, temp1, temp2), search_mhs(mahasiswa, temp3));
            } else if (opsi == 2) {
                string temp1, temp2, temp3;
                cout<<"NIM Mahasiswa : ";
                cin>>temp3;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp1);
                cout<<"Nama Kelas : ";
                cin>>temp2;
                delete_Relasi(search_MK(Matakuliah, temp1, temp2), search_mhs(mahasiswa, temp3));
            } else if (opsi == 3) {
                print_Full(Matakuliah);
            } else if (opsi == 4) {
                string temp;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp);
                print_MK_Kuota(Matakuliah, temp);
            } else if (opsi == 0) {
                fase++;
            } else {
                cout << "Salah memasukkan pilihan" << endl;
            }
            cout << endl;
        } else if(fase == 3) {
            P = Matakuliah.first;
            while(P != NULL) {
                if(P->info.jumlah == 0) {
                    delete_MK(Matakuliah, P);
                }
                P = P->next;
            }
            int opsi;
            cout<<"Tahap Penyelesaian:"<<endl;
            cout<<"(1) Tampilkan seluruh mata kuliah beserta pendaftarnya"<<endl;
            cout<<"(2) Tampilkan pendaftar pada mata kuliah tertentu"<<endl;
            cout<<"(9) Kembali ke Tahap Pemasukan Mata Kuliah"<< endl;
            cout<<"(0) End Program"<<endl;
            cout<<"Pilih : ";
            cin >> opsi;

            if (opsi == 1) {
                print_Full(Matakuliah);
            } else if (opsi == 2) {
                string temp1, temp2;
                cout<<"Nama Mata Kuliah : ";
                cin.ignore();
                getline(cin, temp1);
                cout<<"Nama Kelas : ";
                cin>>temp2;
                print_Half_Full(Matakuliah, temp1, temp2);
            } else if (opsi == 9) {
                fase = 0;
                system("CLS");
            } else if (opsi == 0){
                fase = -1;
                system("CLS");
                cout<<"~~Program Selesai~~"<<endl;
            }else {
                cout << "Salah memasukkan pilihan" << endl;
            }
            cout << endl;
        }
    }
    return 0;
}
